#!/bin/bash

java -jar Foundations2.jar
